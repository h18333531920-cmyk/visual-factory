(() => {
  const post = payload => window.postMessage({ source: 'vf-jimeng-extension', ...payload }, window.location.origin);
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (data?.source !== 'vf-diy-page' || !data.type) return;
    chrome.runtime.sendMessage(data, response => {
      if (chrome.runtime.lastError) return post({ type: 'vf:jimeng-bridge-error', requestId: data.requestId, message: chrome.runtime.lastError.message });
      if (response?.error) post({ type: 'vf:jimeng-bridge-error', requestId: data.requestId, message: response.error });
      if (data.type === 'vf:bridge-status') post({ type: 'vf:jimeng-status', ...(response || {}) });
    });
  });
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type === 'vf:jimeng-status' || message?.type === 'vf:jimeng-result') post(message);
  });
  post({ type: 'vf:jimeng-bridge-ready' });
})();
