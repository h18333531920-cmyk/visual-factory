const list = document.getElementById('tabs');
async function render() {
  const tabs = await chrome.tabs.query({});
  const jimeng = tabs.filter(tab => /(^|\.)jimeng\.jianying\.com/i.test(new URL(tab.url || 'https://invalid').hostname));
  if (!jimeng.length) { list.textContent = '未发现已打开的即梦网页。请先在 Chrome 或 Edge 中登录并打开即梦。'; return; }
  list.innerHTML = '';
  jimeng.forEach(tab => {
    const item = document.createElement('button');
    item.className = 'tab'; item.textContent = `连接：${tab.title || '即梦'}`;
    item.onclick = async () => { const result = await chrome.runtime.sendMessage({ type: 'vf:pair-jimeng-tab', tabId: tab.id }); item.textContent = result?.error || '✓ 已连接'; };
    list.append(item);
  });
}
render();
